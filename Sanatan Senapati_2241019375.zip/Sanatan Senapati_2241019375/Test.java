package SanatanSenapati_2241019375;

import java.util.Scanner;
import SanatanSenapati_2241019375.Date;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number of employees:");
		int n = sc.nextInt();
		Employee e[] = new Employee[n];
		for (int i = 0; i < n; i++) {
			System.out.println("Enter Employee " + (i + 1) + " Detail");
			e[i] = new Employee();
		}

		arrangeEmployeeBySalary(e);

		System.out.println("Enter the job position for which you want to display the details of Employee");
		sc.nextLine();
		String jp = sc.nextLine();
		System.out.println("Details of employees whose jobPosition is " + jp);
		getEmployeesByJobPosition(e, jp);

		System.out.println(
				"Enter your hire date range between which you want to get details in the form day month year: ");
		System.out.print("Enter starting of range:");
		Date d1 = new Date(sc.nextInt(), sc.nextInt(), sc.nextInt());
		System.out.print("Enter ending of range:");
		Date d2 = new Date(sc.nextInt(), sc.nextInt(), sc.nextInt());
		System.out.println("Details of employees whose hireDate is between" + d1.day + "/" + d1.month + "/" + d1.year
				+ " to " + d2.day + "/" + d2.month + "/" + d2.year);
		getEmployeesByHireDate(e, d1, d2);

		int no_Of_Foreign_Employee = foreignEmployeeCount(e);
		System.out.println("Number of foreign employees: " + no_Of_Foreign_Employee);

		System.out.println("Enter the range of salary between which you want to display the details of Employee");
		double s1 = sc.nextDouble();
		double s2 = sc.nextDouble();
		System.out.println("Details of employees whose salary is in a range " + s1 + " INR to " + s2 + " INR");
		getEmployeesBySalary(e, s1, s2);

	}

	public static void arrangeEmployeeBySalary(Employee e[]) {
		int i, j;
		for (i = 0; i < e.length; i++) {
			for (j = 0; j < e.length - 1; j++) {
				if (e[j].salary < e[j + 1].salary) {
					Employee obj = e[j];
					e[j] = e[j + 1];
					e[j + 1] = obj;
				}
			}
		}
	}

	public static void getEmployeesByJobPosition(Employee e[], String jp) {
		System.out.println("Name\t\tEmployee_Id\t\tSalary\t\tHire Date\tJob Position\tContact Number\t\tAddress");
		for (int i = 0; i < e.length; i++) {
			if (e[i].jobPosition.equals(jp)) {
				e[i].display();
			}
		}
	}

	public static void getEmployeesByHireDate(Employee e[], Date d1, Date d2) {
		System.out.println("Name\t\tEmployee_Id\t\tSalary\t\tHire Date\tJob Position\tContact Number\t\tAddress");
		for (int i = 0; i < e.length; i++) {
			if ((e[i].hireDate.year == d2.year && e[i].hireDate.month <= d2.month && e[i].hireDate.day <= d2.day)
					|| (e[i].hireDate.year == d1.year && e[i].hireDate.month >= d1.month
							&& e[i].hireDate.day >= d1.day))
				e[i].display();
		}
	}

	public static int foreignEmployeeCount(Employee e[]) {
		int count = 0;
		for (int i = 0; i < e.length; i++) {
			if (!e[i].contactNumber.startsWith("+91")) {
				count++;
			}
		}
		return count;
	}

	public static void getEmployeesBySalary(Employee e[], double s1, double s2) {
		System.out.println("Name\t\tEmployee_Id\t\tSalary\t\tHire Date\tJob Position\tContact Number\t\tAddress");
		for (int i = 0; i < e.length; i++) {
			if (e[i].salary >= s1 && e[i].salary <= s2)
				e[i].display();
		}
	}
}
